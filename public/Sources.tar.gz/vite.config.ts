import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import iteriaLowcode from '@iteria-app/vite-plugin-lowcode'
import * as path from 'path'

export default ({ command, mode }) => {
  //Monorepo purposes only for index.html env literals replacement with htmlPlugin
  process.env = {
    ...process.env,
    ...loadEnv(mode, process.cwd()),
    VITE_CWD: process.cwd(),
    VITE_MODE: mode,
    VITE_COMMAND: command,
    VITE_NETLIFY: process.env.NETLIFY,
    VITE_BRANCH: process.env.BRANCH,
    VITE_REPOSITORY_URL: process.env.REPOSITORY_URL,
    VITE_SITE_ID: process.env.SITE_ID,
  }

  return defineConfig({
    optimizeDeps: {
      exclude: ['@iteria-app/wysiwyg'],
    },
    resolve: {
      alias: {
        os: 'os-browserify',
        path: 'path-browserify',
        module: path.resolve(__dirname, './src/constants.ts'),
      },
      dedupe: ['react', 'react-dom', 'react-router', 'react-router-dom'],
    },
    server: {
      port: 3000,
    },
    plugins: [
      htmlPlugin(process.env), //For monorepo purposes only
      react(),
      iteriaLowcode({
        command,
        mode,
        graphQLEndpoint: process.env.VITE_HASURA_GRAPHQL_ENDPOINT,
        graphQLSecret: process.env.VITE_HASURA_GRAPHQL_SECRET,
        version: 'workspace:*',
        whitelistedEnvs: [
          'VITE_HASURA_GRAPHQL_ENDPOINT',
          'VITE_HASURA_GRAPHQL_SECRET',
          'VITE_BRANCH',
          'VITE_REPOSITORY_URL',
          'VITE_SITE_ID',
          'VITE_NETLIFY',
        ],
      }),
    ],
  })
}

//Just for monorepo purposes, to replace env in index.html TODO move me
function htmlPlugin(env: ReturnType<typeof loadEnv>) {
  return {
    name: 'html-transform',
    transformIndexHtml: {
      enforce: 'pre' as const,
      transform: (html: string): string =>
        html.replace(
          /%(.*?)%/g,
          (match, p1) => env[p1]?.replace(/\\/g, '/') ?? undefined
        ),
    },
  }
}
