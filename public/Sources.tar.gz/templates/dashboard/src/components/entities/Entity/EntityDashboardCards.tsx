import React from 'react'
import { Grid } from '@mui/material'
import EntityDashboardCardItem from './EntityDashboardCardItem'
import { EntitiesQuery } from '../../../generated/graphql'

export interface EntityDashboardCardsProps {
  data: EntitiesQuery
  loading: boolean
}

const EntityDashboardCards: React.FC<EntityDashboardCardsProps> = ({
  data,
  loading,
}) => {
  return (
    <Grid
      container
      width={'100%'}
      sx={{ overflow: 'hidden', marginTop: '20px' }}
    >
      {!loading
        ? data?.Entity?.map((entity) => (
            <EntityDashboardCardItem data={entity} key={entity.id} />
          ))
        : 'Loading...'}
    </Grid>
  )
}

export default EntityDashboardCards
