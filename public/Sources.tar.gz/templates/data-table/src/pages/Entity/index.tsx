import React from 'react'
import EntityDataTableView from '../../components/entities/Entity/EntityDataTableView'
import EntityDataTableContainer from '../../components/entities/Entity/EntityDataTableContainer'

const EntityManyPage: React.FC = () => {
  return (
    <EntityDataTableContainer
      View={({ data, error, loading, onClickRow, filterProps }) => {
        return (
          <EntityDataTableView
            data={data}
            filterProps={filterProps}
            onClickRow={onClickRow}
            loading={loading}
            error={error}
          />
        )
      }}
    />
  )
}

export default EntityManyPage
