import React from 'react'
import EntityFormTable from '../Entity/EntityFormTable'

export const ArrayFormat = ({ value }) => {
  return <EntityFormTable relationshipName={'FIELD'} />
}
