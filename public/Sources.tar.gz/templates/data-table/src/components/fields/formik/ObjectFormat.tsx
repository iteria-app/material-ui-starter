import React from 'react'
import EntityForm from '../Entity/EntityForm'

export const ObjectFormat = ({ value }) => {
  return <EntityForm relationshipName={'FIELD'} />
}
