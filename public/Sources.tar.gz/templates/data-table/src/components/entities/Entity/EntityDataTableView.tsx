import React, { useCallback, useEffect, useState } from 'react'
import { DataGrid, GridCellParams, GridSortModel } from '@mui/x-data-grid'
import { Card, Grid, LinearProgress } from '@mui/material'
import {
  TablePagination,
  SelectPerPage,
  controlNextButton,
  controlSiblings,
  filterDataGrid,
  sortQueryFromGridData,
  FilterProps,
  Translate,
  Toolbar
} from '@iteria-app/component-templates'
import introspection from '../../../generated/introspect.json'
import { EntitiesQuery, IError } from '../../../generated/graphql'
import { FormatEntityField } from '@iteria-app-mui/common'


export interface IFilterQuery {
  limit: number
  offset: number
  orderBy: GridSortModel
}

export interface EntityTableProps {
  data: EntitiesQuery
  filterProps: FilterProps
  onClickRow?: (state: number) => void
  onDeleteRow?: (value: any) => void
  loading: boolean
  error: IError | null
}

const tableColumnTypes = [
  {
    graphQl: 'Int',
    dataGrid: 'number',
  },
  {
    graphQl: 'BigInteger',
    dataGrid: 'number',
  },
  {
    graphQl: 'time',
    dataGrid: 'dateTime',
  },
  {
    graphQl: 'timestamp',
    dataGrid: 'dateTime',
  },
]

const EntityDataTableView: React.FC<EntityTableProps> = ({
  data,
  filterProps,
  onClickRow,
  onDeleteRow,
  loading,
  error,
}) => {
  const [siblingCount, setSiblingCount] = useState(1)
  const [hideNextButton, setHideNextButton] = useState(false)
  const entityIntrospection = introspection?.__schema?.types?.find(
    (type) => type?.name === 'Entity'
  )?.fields

  const {
    page,
    pageSize,
    countRows,
    onSort,
    onChangePage,
    onPageSize,
    onFilter,
    setCountToRows,
  } = filterProps

  useEffect(() => {
    if (!loading) {
      controlNextButton({
        data: data?.Entity ?? [],
        countRows: countRows,
        hideNextButton: hideNextButton,
        setCountToRows: setCountToRows,
        setHideNextButton: setHideNextButton,
        page: page,
        pageSize: pageSize,
      })
      controlSiblings(data?.Entity ?? [], pageSize, page, setSiblingCount)
    }
  }, [data?.Entity])

  const getColumnGraphQlType = (fieldName: string) => {
    const field = entityIntrospection?.find(
      (field) => field?.name === fieldName
    )
    return field?.type?.ofType?.name ?? field?.type?.name
  }

  const getColumnType = (fieldName: string) => {
    const graphQlType = getColumnGraphQlType(fieldName)
    return (
      tableColumnTypes.find((type) => type.graphQl === graphQlType)?.dataGrid ??
      'string'
    )
  }

  const getRelationshipField = (fieldName: string) => {
    return fieldName.includes('.') ? fieldName.split('.').slice(1).join('.') : fieldName
  }

  const columns = [
    {
      field: 'FIELD',
      type: getColumnType('FIELD'),
      renderHeader: () => (
        <Translate
          entityName={'Entity'}
          fieldName={getRelationshipField('FIELD')}
          defaultMessage={'HEADER_NAME'}
        />
      ),
      minWidth: 150,
      flex: 2,
      renderCell: (params: GridCellParams) => (
        <FormatEntityField value={params.row.FIELD} type={'string'} />
      ),
      columnType: getColumnGraphQlType('FIELD'),
    },
  ]

  const handlePage = (event: any, newPage: number) => {
    onChangePage(newPage)
  }

  const handlePageSize = (event: any) => {
    onPageSize(event.target.value)
    onChangePage(1)
  }

  const handleFilter = useCallback(
    (filter) => {
      onFilter?.(filterDataGrid(filter, columns))
      onChangePage(1)
    },
    [onFilter, handlePage]
  )

  const handleSort = (sort: GridSortModel) => {
    onSort(sortQueryFromGridData(sort))
  }

  return (
    <Card>
      <Toolbar filterProps={filterProps} introspection={entityIntrospection} />
      <DataGrid
        rows={data?.Entity ?? []}
        columns={columns}
        loading={loading}
        hideFooterPagination
        autoHeight={true}
        error={error}
        sortingMode="server"
        filterMode="server"
        onSortModelChange={handleSort}
        onFilterModelChange={handleFilter}
        onRowClick={(event) => {
          if (onClickRow) onClickRow(event.row?.id)
        }}
        components={{
          LoadingOverlay: LinearProgress,
          Footer: () => (
            <Grid container>
              <TablePagination
                countRows={countRows}
                page={page}
                handlePage={handlePage}
                siblingCount={siblingCount}
                hideNextButton={hideNextButton}
              />
              <SelectPerPage
                pageSize={pageSize}
                handlePageSize={handlePageSize}
              />
            </Grid>
          ),
        }}
      />
    </Card>
  )
}

export default EntityDataTableView
