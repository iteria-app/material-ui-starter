import React from 'react'
import { MapContainer, TileLayer, GeoJSON, useMapEvents } from 'react-leaflet'
import { FilterProps, getJson } from '@iteria-app/component-templates'
import { useNavigate } from 'react-router-dom'
import { EntitiesQuery } from '../../../generated/graphql'
export interface EntityListProps {
  data: EntitiesQuery | null
  filterProps: FilterProps
}

const EntityListLeaflet: React.FC<EntityListProps> = ({ data, filterProps }) => {
  const navigate = useNavigate()
  const EventListeners = ({ filterProps }: { filterProps: FilterProps }) => {
    useMapEvents({
      moveend(event) {
        const bounds = event.target.getBounds()
        console.log(bounds) 
        const polygon = {
          type: 'Polygon',
          coordinates: [
            [
              [bounds._southWest.lng, bounds._southWest.lat],
              [bounds._southWest.lng, bounds._northEast.lat],
              [bounds._northEast.lng, bounds._northEast.lat],
              [bounds._northEast.lng, bounds._southWest.lat],
              [bounds._southWest.lng, bounds._southWest.lat],
            ],
          ],
          crs: { type: 'name', properties: { name: 'EPSG:4326' } },
        }
        if (data?.Entity?.[0]) {
          const jsonKeys = getJson(data.Entity[0], true)
          // FIXME: should chcek for Geometry type
          console.log('mgcsk', jsonKeys)
          
          setTimeout(() => {
            const filter = jsonKeys.map((jsonKey) => {
              return {
                [jsonKey]: { _cast: { geometry: { _st_intersects: polygon } } }, 
              }
            })
            filterProps.onFilter(filter ? { _or: filter } : {})
          }, 300) // FIXME debounce
        }
      },
    })

    return null
  }
  return (
    <MapContainer
      center={[45.74739, -105]}
      zoom={6}
      scrollWheelZoom={true}
      style={{ height: '90vh' }}
    >
      <EventListeners filterProps={filterProps} />
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {data?.Entity?.map((entity) => {
        const geoJsons = getJson(entity)
        // FIXME: should chcek for Geometry type
        // TODO: display different colums as layers
        return geoJsons?.map((json) => {
          try {
            return (
              <GeoJSON
                key={entity?.id}
                data={json}
                onEachFeature={(_, layer) => {
                  layer.on({ click: () => navigate(entity?.id) })
                }}
              />
            )
          } catch (error) {
            return <></>
          }
        })
      })}
    </MapContainer>
  )
}

export default EntityListLeaflet
