import React from 'react'
import { ImageSection } from '../../components/ImageSection'

const HomePage: React.FC = () => {
  return <ImageSection value="test" />
}

export default HomePage
