import { Typography } from '@mui/material'
import React from 'react'

export const DefaultFormat = ({ value }) => {
  return <Typography>{value}</Typography>
}
