import { Chip } from '@mui/material'
import React from 'react'

export const DefaultFormat = ({ value }) => {
  return <Chip label={value} />
}
