import { Grid } from '@mui/material'
import React from 'react'

export const ArrayFormat = ({ value }) => {
  return <></>
}
