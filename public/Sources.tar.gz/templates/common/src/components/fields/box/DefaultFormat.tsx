import { Box } from '@mui/material'
import React from 'react'

export const DefaultFormat = ({ value }) => {
  return <Box>{value}</Box>
}
