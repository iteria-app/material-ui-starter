import { Box } from '@mui/material'
import React from 'react'

export const StringFormat = ({ value }: { value?: string }) => {
  return <Box>{value}</Box>
}
