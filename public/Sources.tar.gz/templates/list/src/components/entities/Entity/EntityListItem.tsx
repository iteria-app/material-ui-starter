import {
  Avatar,
  Checkbox,
  ListItem,
  ListItemAvatar,
  ListItemButton,
  ListItemText,
  useTheme,
} from '@mui/material'
import { useNavigate } from 'react-router-dom'
import React from 'react'
import { FormatEntityField } from '@iteria-app-mui/common'
import { getImagePath, getName, RowOfItems, stringAvatar } from '@iteria-app/component-templates'
import { EntityFragment } from '../../../generated/graphql'

interface EntityListItem {
  data: EntityFragment
}

const EntityListItem: React.FC<EntityListItem> = ({ data }) => {
  const theme = useTheme()
  const navigate = useNavigate()
  const columns = [
    <>
      <FormatEntityField key={'FIELD'} type={'string'} value={data?.FIELD} />
    </>,
  ]
  return (
    <ListItem
      secondaryAction={<Checkbox onClick={(e) => e.stopPropagation()} />}
      disablePadding
      sx={{ background: theme.palette.background.paper, borderRadius: '20px' }}
    >
      <ListItemButton onClick={() => navigate(data?.id.toString())}>
        <ListItemAvatar>
          <Avatar src={getImagePath(data)} {...stringAvatar(getName(data))} />
        </ListItemAvatar>
        <ListItemText
          primary={columns[0]}
          secondary={
            <RowOfItems data={columns.slice(1)}/>
          }
        />
      </ListItemButton>
    </ListItem>
  )
}

export default EntityListItem
