import React from 'react'
import { LookupDialog } from './LookupDialog'
import CmdbDataTableContainerForForm from './cmdb/CmdbDataTableContainerForForm'
import CmdbDataTableGridViewForForm from './cmdb/CmdbDataTableGridViewForForm'
import Button from '@mui/material/Button'
import { Search } from '@mui/icons-material'
import { Translate } from '@iteria-app/component-templates'
type Props = {
  setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  replacedValue: string
}
export const CmdbLookupDialogWrapperForForm = ({
  setFieldValue,
  replacedValue,
}: Props) => {
  return (
    <LookupDialog
      Container={CmdbDataTableContainerForForm}
      View={CmdbDataTableGridViewForForm}
      radio
      onSubmit={(rows) => {
        setFieldValue(replacedValue, rows?.[0], false)
      }}
      title={replacedValue}
    >
      <Button
        color="secondary"
        variant="contained"
        startIcon={<Search />}
        style={{ margin: '16px' }}
      >
        <Translate
          entityName={replacedValue}
          fieldName="lookup"
          defaultMessage={`Lookup ${replacedValue}`}
        />
      </Button>
    </LookupDialog>
  )
}
