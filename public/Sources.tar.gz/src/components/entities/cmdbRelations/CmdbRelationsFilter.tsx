import {
  createColumnData,
  createFilterData,
  createFilterItem,
  filterByTabName,
  FilterDataStorage,
  FilterProps,
  getColumnsOperandFilterData,
  getFieldValue,
  getOperandForType,
  getTabNameFromIndex,
  getTypeFromField,
  getTypeOfField,
  handleNewDefaultField,
  handleOnChange,
  handleOnChangeSetField,
  useFilter,
  columnCount,
} from '@iteria-app/component-templates'
import React, { useEffect, ChangeEventHandler, FocusEventHandler } from 'react'
import { EntitiesQuery } from '../../../generated/graphql'
import { FormField } from '../FormField'
import { FieldProps, useFormikContext } from 'formik'
import { Grid, InputLabel, Input, TextField } from '@mui/material'
import { useSearchParams } from 'react-router-dom'
type Props = {
  filterCallbacks?: FilterProps
  dataStorage?: FilterDataStorage
}
const CmdbRelationsFilter = ({ filterCallbacks, dataStorage }: Props) => {
  const formikProps = useFormikContext()
  const [urlParams, setUrlSearchParams] = useSearchParams()
  const currentParams = Object.fromEntries([...(urlParams ?? [])])
  useEffect(() => {
    const realCurrentParams =
      dataStorage === FilterDataStorage.QUERY_PARAMETERS ? currentParams : {}
    const keys = Object.keys(realCurrentParams)
    const filterData = createFilterData(keys, realCurrentParams)
    const columnsData = createColumnData(keys)
    filterCallbacks?.handleToolbarFilter(filterData, columnsData)
  }, [])
  const columns = [
    <>
      <Grid container alignItems="center" paddingY={1}>
        <TextField
          name="fk"
          label="fk"
          variant="standard"
          title="fk"
          onChange={(event: Event) =>
            handleOnChange(
              'fk',
              event,
              dataStorage,
              currentParams,
              filterCallbacks,
              setUrlSearchParams
            )
          }
          onClick={(event) => {
            event.stopPropagation()
          }}
          InputProps={{
            startAdornment: <></>,
          }}
          fullWidth
          type="string"
          value={getFieldValue('fk', dataStorage, currentParams) ?? ''}
        />
      </Grid>
    </>,
    <>
      <Grid container alignItems="center" paddingY={1}>
        <TextField
          name="type"
          label="type"
          variant="standard"
          title="type"
          onChange={(event: Event) =>
            handleOnChange(
              'type',
              event,
              dataStorage,
              currentParams,
              filterCallbacks,
              setUrlSearchParams
            )
          }
          onClick={(event) => {
            event.stopPropagation()
          }}
          InputProps={{
            startAdornment: <></>,
          }}
          fullWidth
          type="string"
          value={getFieldValue('type', dataStorage, currentParams) ?? ''}
        />
      </Grid>
    </>,
  ]
  return <>{columns?.map((field) => field)}</>
}
export default CmdbRelationsFilter
