import React from 'react'
import { Formik, useFormikContext, FieldProps } from 'formik'
import { Typography } from '@mui/material'
import {
  FormatFieldCellWrapper,
  TableRow,
  TranslateTableCellWrapper,
  columnCount,
} from '@iteria-app/component-templates'
import { FormField } from '../FormField'
interface IProps {
  rootName?: string
  relationshipName?: string
  index?: number
  value?: any
}
const CmdbRelationsForm: React.FC<IProps> = ({
  rootName,
  relationshipName,
  index,
  value,
}) => {
  const formikProps = useFormikContext()
  const columns = [
    <TableRow key="fk">
      <TranslateTableCellWrapper
        headerName="Fk"
        entityName="cmdbRelations"
        fieldToReplace="fk"
      />
      <FormatFieldCellWrapper>
        <FormField
          fieldName="fk"
          rootName={rootName}
          relationshipName={relationshipName}
          index={index}
        >
          {(fieldProps: FieldProps) => {
            return <Typography>{fieldProps.field.value ?? ''}</Typography>
          }}
        </FormField>
      </FormatFieldCellWrapper>
    </TableRow>,
    <TableRow key="type">
      <TranslateTableCellWrapper
        headerName="Type"
        entityName="cmdbRelations"
        fieldToReplace="type"
      />
      <FormatFieldCellWrapper>
        <FormField
          fieldName="type"
          rootName={rootName}
          relationshipName={relationshipName}
          index={index}
        >
          {(fieldProps: FieldProps) => {
            return <Typography>{fieldProps.field.value ?? ''}</Typography>
          }}
        </FormField>
      </FormatFieldCellWrapper>
    </TableRow>,
  ]
  return <>{columns}</>
}
export default CmdbRelationsForm
