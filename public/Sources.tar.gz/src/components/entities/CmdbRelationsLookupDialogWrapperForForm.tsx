import React from 'react'
import { LookupDialog } from './LookupDialog'
import CmdbRelationsDataTableContainerForForm from './cmdbRelations/CmdbRelationsDataTableContainerForForm'
import CmdbRelationsDataTableGridViewForForm from './cmdbRelations/CmdbRelationsDataTableGridViewForForm'
import Button from '@mui/material/Button'
import { Search } from '@mui/icons-material'
import { Translate } from '@iteria-app/component-templates'
type Props = {
  setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  replacedValue: string
}
export const CmdbRelationsLookupDialogWrapperForForm = ({
  setFieldValue,
  replacedValue,
}: Props) => {
  return (
    <LookupDialog
      Container={CmdbRelationsDataTableContainerForForm}
      View={CmdbRelationsDataTableGridViewForForm}
      radio
      onSubmit={(rows) => {
        setFieldValue(replacedValue, rows?.[0], false)
      }}
      title={replacedValue}
    >
      <Button
        color="secondary"
        variant="contained"
        startIcon={<Search />}
        style={{ margin: '16px' }}
      >
        <Translate
          entityName={replacedValue}
          fieldName="lookup"
          defaultMessage={`Lookup ${replacedValue}`}
        />
      </Button>
    </LookupDialog>
  )
}
