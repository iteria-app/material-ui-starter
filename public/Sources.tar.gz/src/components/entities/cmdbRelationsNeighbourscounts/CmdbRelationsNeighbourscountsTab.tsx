import React from 'react'
import { Box, TableRow, Typography } from '@mui/material'
import { FormField } from '../FormField'
import {
  FormatFieldCellWrapper,
  TranslateTableCellWrapper,
  columnCount,
} from '@iteria-app/component-templates'
import { CmdbRelationsNeighbourscountsFragment } from '../../../generated/graphql'
import { useFormikContext, FieldProps } from 'formik'
interface CmdbRelationsNeighbourscountsTabProps {
  data: CmdbRelationsNeighbourscountsFragment
  visible: boolean
  relationshipName?: string
  index?: number
}
const CmdbRelationsNeighbourscountsTab: React.FC<
  CmdbRelationsNeighbourscountsTabProps
> = ({ data, visible, relationshipName, index }) => {
  const formikProps = useFormikContext()
  let formikContext
  if (relationshipName) formikContext = useFormikContext()
  const setFieldValue = formikContext?.setFieldValue
  const columns = [
    <TableRow key="AS">
      <TranslateTableCellWrapper
        headerName="AS"
        entityName="cmdbRelationsNeighbourscounts"
        fieldToReplace="AS"
      />
      <FormatFieldCellWrapper>
        <FormField
          fieldName="AS"
          relationshipName={relationshipName}
          index={index}
        >
          {(fieldProps: FieldProps) => {
            return <Typography>{fieldProps.field.value ?? ''}</Typography>
          }}
        </FormField>
      </FormatFieldCellWrapper>
    </TableRow>,
    <TableRow key="InfraSluzba">
      <TranslateTableCellWrapper
        headerName="InfraSluzba"
        entityName="cmdbRelationsNeighbourscounts"
        fieldToReplace="InfraSluzba"
      />
      <FormatFieldCellWrapper>
        <FormField
          fieldName="InfraSluzba"
          relationshipName={relationshipName}
          index={index}
        >
          {(fieldProps: FieldProps) => {
            return <Typography>{fieldProps.field.value ?? ''}</Typography>
          }}
        </FormField>
      </FormatFieldCellWrapper>
    </TableRow>,
    <TableRow key="KRIS">
      <TranslateTableCellWrapper
        headerName="KRIS"
        entityName="cmdbRelationsNeighbourscounts"
        fieldToReplace="KRIS"
      />
      <FormatFieldCellWrapper>
        <FormField
          fieldName="KRIS"
          relationshipName={relationshipName}
          index={index}
        >
          {(fieldProps: FieldProps) => {
            return <Typography>{fieldProps.field.value ?? ''}</Typography>
          }}
        </FormField>
      </FormatFieldCellWrapper>
    </TableRow>,
    <TableRow key="Kontrakt">
      <TranslateTableCellWrapper
        headerName="Kontrakt"
        entityName="cmdbRelationsNeighbourscounts"
        fieldToReplace="Kontrakt"
      />
      <FormatFieldCellWrapper>
        <FormField
          fieldName="Kontrakt"
          relationshipName={relationshipName}
          index={index}
        >
          {(fieldProps: FieldProps) => {
            return <Typography>{fieldProps.field.value ?? ''}</Typography>
          }}
        </FormField>
      </FormatFieldCellWrapper>
    </TableRow>,
    <TableRow key="OLA_Kontrakt">
      <TranslateTableCellWrapper
        headerName="OLA Kontrakt"
        entityName="cmdbRelationsNeighbourscounts"
        fieldToReplace="OLA_Kontrakt"
      />
      <FormatFieldCellWrapper>
        <FormField
          fieldName="OLA_Kontrakt"
          relationshipName={relationshipName}
          index={index}
        >
          {(fieldProps: FieldProps) => {
            return <Typography>{fieldProps.field.value ?? ''}</Typography>
          }}
        </FormField>
      </FormatFieldCellWrapper>
    </TableRow>,
    <TableRow key="PO">
      <TranslateTableCellWrapper
        headerName="PO"
        entityName="cmdbRelationsNeighbourscounts"
        fieldToReplace="PO"
      />
      <FormatFieldCellWrapper>
        <FormField
          fieldName="PO"
          relationshipName={relationshipName}
          index={index}
        >
          {(fieldProps: FieldProps) => {
            return <Typography>{fieldProps.field.value ?? ''}</Typography>
          }}
        </FormField>
      </FormatFieldCellWrapper>
    </TableRow>,
    <TableRow key="Projekt">
      <TranslateTableCellWrapper
        headerName="Projekt"
        entityName="cmdbRelationsNeighbourscounts"
        fieldToReplace="Projekt"
      />
      <FormatFieldCellWrapper>
        <FormField
          fieldName="Projekt"
          relationshipName={relationshipName}
          index={index}
        >
          {(fieldProps: FieldProps) => {
            return <Typography>{fieldProps.field.value ?? ''}</Typography>
          }}
        </FormField>
      </FormatFieldCellWrapper>
    </TableRow>,
  ]
  return (
    <div role="tabpanel" hidden={!visible}>
      {visible && <Box sx={{ p: 3 }}>{columns}</Box>}
    </div>
  )
}
export default CmdbRelationsNeighbourscountsTab
