import React from 'react'
import CmdbRelationsNeighbourscountsTab from './CmdbRelationsNeighbourscountsTab'
import { CmdbRelationsNeighbourscountsFragment } from '../../../generated/graphql'
import { ViewGridTemplate, getTitle } from '@iteria-app/component-templates'
import { Box, Tabs, Tab } from '@mui/material'
export interface CmdbRelationsNeighbourscountsTabsProps {
  data?: CmdbRelationsNeighbourscountsFragment[]
  relationshipName?: string
  onTabsChanged?: (event, newValue, value) => void
}
const CmdbRelationsNeighbourscountsTabs: React.FC<CmdbRelationsNeighbourscountsTabsProps> =
  ({ data, relationshipName, onTabsChanged }) => {
    const [value, setValue] = React.useState(0)
    const handleChange = (event: React.SyntheticEvent, newValue: number) => {
      setValue(newValue)
      onTabsChanged?.(event, newValue, data)
    }
    return (
      <ViewGridTemplate>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs value={value} onChange={handleChange}>
            {data?.map((cmdbRelationsNeighbourscounts, index) => (
              <Tab
                label={
                  cmdbRelationsNeighbourscounts?.label ??
                  (cmdbRelationsNeighbourscounts
                    ? cmdbRelationsNeighbourscounts?.AS
                    : `Tab ${index + 1}`)
                }
                key={index}
              />
            ))}
          </Tabs>
        </Box>
      </ViewGridTemplate>
    )
  }
export default CmdbRelationsNeighbourscountsTabs
