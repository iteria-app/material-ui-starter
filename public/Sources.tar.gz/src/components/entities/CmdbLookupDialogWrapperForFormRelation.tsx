import React from 'react'
import { LookupDialog } from './LookupDialog'
import CmdbDataTableContainerForFormRelation from './cmdb/CmdbDataTableContainerForFormRelation'
import CmdbDataTableGridViewForFormRelation from './cmdb/CmdbDataTableGridViewForFormRelation'
import Button from '@mui/material/Button'
import { Search } from '@mui/icons-material'
import { Translate } from '@iteria-app/component-templates'
type Props = {
  setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  replacedValue: string
}
export const CmdbLookupDialogWrapperForFormRelation = ({
  setFieldValue,
  replacedValue,
}: Props) => {
  return (
    <LookupDialog
      Container={CmdbDataTableContainerForFormRelation}
      View={CmdbDataTableGridViewForFormRelation}
      radio
      onSubmit={(rows) => {
        setFieldValue(replacedValue, rows?.[0], false)
      }}
      title={replacedValue}
    >
      <Button
        color="secondary"
        variant="contained"
        startIcon={<Search />}
        style={{ margin: '16px' }}
      >
        <Translate
          entityName={replacedValue}
          fieldName="lookup"
          defaultMessage={`Lookup ${replacedValue}`}
        />
      </Button>
    </LookupDialog>
  )
}
