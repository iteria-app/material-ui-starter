import React from 'react'
import {
  FormikHelpers,
  FormikValues,
  useFormikContext,
  FieldProps,
} from 'formik'
import CmdbRelationsNeighbourscountsTabs from '../cmdbRelationsNeighbourscounts/CmdbRelationsNeighbourscountsTabs'
import CmdbRelationsFilter from '../cmdbRelations/CmdbRelationsFilter'
import CmdbRelationsDataTableGridViewForForm from '../cmdbRelations/CmdbRelationsDataTableGridViewForForm'
import CmdbRelationsDataTableContainerForForm from '../cmdbRelations/CmdbRelationsDataTableContainerForForm'
import { AccordionCard } from '../AccordionCard'
import { FormField } from '../FormField'
import { FormCard } from '../FormCard'
import { CmdbLookupDialogWrapperForFormBasic } from '../CmdbLookupDialogWrapperForFormBasic'
import CmdbFormBasic from './CmdbFormBasic'
import {
  Box,
  Button,
  CardActions,
  CardContent,
  Grid,
  Typography,
} from '@mui/material'
import { FileCopy, Save } from '@mui/icons-material'
import {
  createEmptyObject,
  filterByTabName,
  FilterDataStorage,
  getTabNameFromIndex,
  handleOnChange,
  Translate,
  useFilter,
  columnCount,
  getTabsValues,
} from '@iteria-app/component-templates'
import { LoadingButton } from '@mui/lab'
import * as generatedGraphql from '../../../generated/graphql'
interface Props {
  data?: generatedGraphql.CmdbQuery
  onSubmit: (
    values: FormikValues,
    formikHelpers: FormikHelpers<FormikValues>
  ) => void
  onCopy?: (
    values: FormikValues,
    formikHelpers: FormikHelpers<FormikValues>
  ) => void
  saveButtonDisabled?: boolean
}
const CmdbFormBasicView: React.FC<Props> = ({
  data,
  onSubmit,
  onCopy,
  saveButtonDisabled,
}) => {
  const formikProps = useFormikContext()
  return (
    <div style={{ marginLeft: 25, marginRight: 25 }}>
      <Typography variant="h1" align="center">
        <Translate
          entityName="cmdb"
          fieldName="heading"
          defaultMessage="cmdb"
        />
      </Typography>
      <Typography align="center">
        <Translate
          entityName="cmdb"
          fieldName="message"
          defaultMessage="Edit this text using the translate tool"
        />
      </Typography>
      <Box sx={{ marginY: 2 }}>
        <CardContent>
          <form onSubmit={formikProps.handleSubmit}>
            <Grid container spacing={3}>
              <FormCard title={'cmdb'}>
                <CmdbFormBasic rootName={'cmdb_by_pk' ?? 'ROOT_NAME'} />
                {undefined && formikProps?.setFieldValue && (
                  <CmdbLookupDialogWrapperForFormBasic
                    setFieldValue={formikProps?.setFieldValue}
                    replacedValue="ROOT_NAME.undefined"
                  />
                )}
              </FormCard>
              <FormField fieldName="cmdbRelations" rootName="">
                {(fieldProps: FieldProps) => {
                  return (
                    <FormCard title="cmdbRelations" length={12}>
                      <CmdbRelationsDataTableContainerForForm
                        View={({
                          data,
                          error,
                          loading,
                          onClickRow,
                          filterProps,
                        }) => (
                          <>
                            <Box>
                              <FormField
                                fieldName="cmdb_relations_neighbourscount"
                                rootName="cmdb_by_pk"
                              >
                                {(fieldProps: FieldProps) => {
                                  return (
                                    <CmdbRelationsNeighbourscountsTabs
                                      data={getTabsValues(
                                        fieldProps.field.value
                                      )}
                                      onTabsChanged={(e, newValue, allData) =>
                                        filterByTabName(
                                          'type',
                                          getTabNameFromIndex(
                                            allData ?? {},
                                            newValue
                                          ),
                                          filterProps ?? useFilter()
                                        )
                                      }
                                    />
                                  )
                                }}
                              </FormField>
                              <CmdbRelationsDataTableGridViewForForm
                                data={data?.cmdbRelations}
                                filterProps={filterProps}
                                onClickRow={onClickRow}
                                loading={loading}
                                error={error}
                              >
                                <CmdbRelationsFilter
                                  filterCallbacks={filterProps}
                                  dataStorage={FilterDataStorage.LOCAL_STATE}
                                />
                              </CmdbRelationsDataTableGridViewForForm>
                            </Box>
                          </>
                        )}
                      />
                    </FormCard>
                  )
                }}
              </FormField>
            </Grid>
            <CardActions>
              <LoadingButton
                disabled={saveButtonDisabled}
                loading={formikProps.isSubmitting}
                loadingPosition="start"
                startIcon={<Save />}
                style={{
                  margin: '12px auto',
                }}
                variant="contained"
                type="submit"
                data-test-id="save-entity-button"
              >
                <Translate entityName="Save" />
              </LoadingButton>
              {onCopy !== undefined && (
                <LoadingButton
                  disabled={saveButtonDisabled}
                  color="secondary"
                  loading={formikProps.isSubmitting}
                  loadingPosition="start"
                  startIcon={<FileCopy />}
                  style={{
                    margin: '12px auto',
                  }}
                  variant="contained"
                  onClick={() => {
                    if (onCopy) {
                      onCopy(data as FormikValues, formikProps)
                    }
                  }}
                  data-test-id="copy-entity-button"
                >
                  <Translate entityName="Copy" />
                </LoadingButton>
              )}
            </CardActions>
          </form>
        </CardContent>
      </Box>
    </div>
  )
}
export default CmdbFormBasicView
