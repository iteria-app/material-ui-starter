import React from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import {
  useCmdb_By_PkQuery,
  useInsert_CmdbMutation,
} from '../../../generated/graphql'
import {
  createEmptyObject,
  deepClone,
  Error,
  ErrorBoundary,
  Fetching,
  parseRequestErrors,
  QueryBoundary,
  showErrorSnackbar,
  showLoadingSnackbar,
  showSuccessSnackbar,
} from '@iteria-app/component-templates'
import { Formik, FormikHelpers, FormikValues } from 'formik'
import { getUpsertQuery } from '@iteria-app/graphql-lowcode'
import { useIntl } from 'react-intl'
import * as generatedGraphql from '../../../generated/graphql'
import introspection from '../../../generated/introspect.json'
interface IViewProps {
  data: generatedGraphql.CmdbQuery
  onSubmit: (
    values: FormikValues,
    formikHelpers: FormikHelpers<FormikValues>
  ) => void
  onCopy: (
    values: FormikValues,
    formikHelpers: FormikHelpers<FormikValues>
  ) => void
}
interface CmdbFormContainerProps {
  View: React.FC<IViewProps>
}
const CmdbFormContainer: React.FC<CmdbFormContainerProps> = ({ View }) => {
  const { id } = useParams()
  const navigate = useNavigate()
  const intl = useIntl()
  const [insertedData, insertMutation] = useInsert_CmdbMutation()
  let data
  if (id !== 'create') {
    ;[data] = useCmdb_By_PkQuery({
      variables: { CmdbId: id },
    })
  }
  const handleSubmit = (
    values: FormikValues,
    formikHelpers: FormikHelpers<FormikValues>
  ) => {
    formikHelpers.setSubmitting(true)
    showLoadingSnackbar(
      intl.formatMessage({
        id: 'submit.inprogress',
        defaultMessage: 'Submitting...',
      })
    )
    insertMutation(getUpsertQuery(values, generatedGraphql)).then(
      (response) => {
        if (response.error) {
          showErrorSnackbar(
            intl.formatMessage({
              id: 'submit.failed',
              defaultMessage: 'Submit failed: ',
            }) + parseRequestErrors(response.error.message, intl)
          )
          console.error('Submit error:', response.error)
        } else {
          showSuccessSnackbar(
            intl.formatMessage({
              id: 'submit.successful',
              defaultMessage: 'Submit successful',
            })
          )
        }
        formikHelpers.setSubmitting(false)
        const newId =
          response.data?.[`${Object.keys(response.data)[0]}`]?.returning?.[0]
            ?.id
        if (newId) {
          navigate(-1)
        }
      }
    )
  }
  const handleCopy = (
    values: FormikValues,
    formikHelpers: FormikHelpers<FormikValues>
  ) => {
    handleSubmit(deepClone(values), formikHelpers)
  }
  if (data?.fetching) return <Fetching />
  if (data?.error) return <Error error={data?.error} />
  return (
    <ErrorBoundary>
      <QueryBoundary queryResponse={data}>
        <Formik
          initialValues={
            data?.data ??
            createEmptyObject('cmdb_by_pk', generatedGraphql, introspection)
          }
          onSubmit={handleSubmit}
          validateOnChange={false}
          validateOnBlur={false}
        >
          <View data={data?.data} onSubmit={handleSubmit} onCopy={handleCopy} />
        </Formik>
      </QueryBoundary>
    </ErrorBoundary>
  )
}
export default CmdbFormContainer
