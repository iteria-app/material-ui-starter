import React, { ChangeEventHandler, FocusEventHandler } from 'react'
import { Formik, useFormikContext, FieldProps } from 'formik'
import { Grid, InputLabel, Input, TextField } from '@mui/material'
import { FormField } from '../FormField'
import {
  FormatFieldCellWrapper,
  TableRow,
  TranslateTableCellWrapper,
  columnCount,
} from '@iteria-app/component-templates'
interface IProps {
  rootName?: string
  relationshipName?: string
  index?: number
  value?: any
}
const CmdbForm: React.FC<IProps> = ({
  rootName,
  relationshipName,
  index,
  value,
}) => {
  const formikProps = useFormikContext()
  const columns = []
  return <>{columns}</>
}
export default CmdbForm
