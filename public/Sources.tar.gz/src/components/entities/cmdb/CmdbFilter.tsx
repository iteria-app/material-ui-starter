import {
  createColumnData,
  createFilterData,
  createFilterItem,
  filterByTabName,
  FilterDataStorage,
  FilterProps,
  getColumnsOperandFilterData,
  getFieldValue,
  getOperandForType,
  getTabNameFromIndex,
  getTypeFromField,
  getTypeOfField,
  handleNewDefaultField,
  handleOnChange,
  handleOnChangeSetField,
  useFilter,
} from '@iteria-app/component-templates'
import React, { useEffect, ChangeEventHandler, FocusEventHandler } from 'react'
import { EntitiesQuery } from '../../../generated/graphql'
import { Grid, InputLabel, Input, TextField } from '@mui/material'
import { useSearchParams } from 'react-router-dom'
type Props = {
  filterCallbacks?: FilterProps
  dataStorage?: FilterDataStorage
}
const CmdbFilter = ({ filterCallbacks, dataStorage }: Props) => {
  const [urlParams, setUrlSearchParams] = useSearchParams()
  const currentParams = Object.fromEntries([...(urlParams ?? [])])
  useEffect(() => {
    const realCurrentParams =
      dataStorage === FilterDataStorage.QUERY_PARAMETERS ? currentParams : {}
    const keys = Object.keys(realCurrentParams)
    const filterData = createFilterData(keys, realCurrentParams)
    const columnsData = createColumnData(keys)
    filterCallbacks?.handleToolbarFilter(filterData, columnsData)
  }, [])
  const columns = [
    <>
      <Grid container alignItems="center" paddingY={1}>
        <TextField
          name="type"
          label="type"
          variant="standard"
          title="type"
          onChange={(event: Event) =>
            handleOnChange(
              'type',
              event,
              dataStorage,
              currentParams,
              filterCallbacks,
              setUrlSearchParams
            )
          }
          onClick={(event) => {
            event.stopPropagation()
          }}
          InputProps={{
            startAdornment: <></>,
          }}
          fullWidth
          type="string"
          value={getFieldValue('type', dataStorage, currentParams) ?? ''}
        />
      </Grid>
    </>,
    <>
      <Grid container alignItems="center" paddingY={1}>
        <TextField
          name="uuid"
          label="uuid"
          variant="standard"
          title="uuid"
          onChange={(event: Event) =>
            handleOnChange(
              'uuid',
              event,
              dataStorage,
              currentParams,
              filterCallbacks,
              setUrlSearchParams
            )
          }
          onClick={(event) => {
            event.stopPropagation()
          }}
          InputProps={{
            startAdornment: <></>,
          }}
          fullWidth
          type="string"
          value={getFieldValue('uuid', dataStorage, currentParams) ?? ''}
        />
      </Grid>
    </>,
  ]
  return <>{columns?.map((field) => field)}</>
}
export default CmdbFilter
