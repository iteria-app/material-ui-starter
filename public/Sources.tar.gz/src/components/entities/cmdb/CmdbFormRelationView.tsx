import React from 'react'
import { FormikHelpers, FormikValues, useFormikContext } from 'formik'
import { AccordionCard } from '../AccordionCard'
import { FormCard } from '../FormCard'
import { CmdbLookupDialogWrapperForFormRelation } from '../CmdbLookupDialogWrapperForFormRelation'
import CmdbFormRelation from './CmdbFormRelation'
import {
  Box,
  Button,
  CardActions,
  CardContent,
  Grid,
  Typography,
} from '@mui/material'
import { FileCopy, Save } from '@mui/icons-material'
import {
  createEmptyObject,
  filterByTabName,
  FilterDataStorage,
  getTabNameFromIndex,
  handleOnChange,
  Translate,
  useFilter,
} from '@iteria-app/component-templates'
import { LoadingButton } from '@mui/lab'
import * as generatedGraphql from '../../../generated/graphql'
interface Props {
  data?: generatedGraphql.CmdbQuery
  onSubmit: (
    values: FormikValues,
    formikHelpers: FormikHelpers<FormikValues>
  ) => void
  onCopy?: (
    values: FormikValues,
    formikHelpers: FormikHelpers<FormikValues>
  ) => void
  saveButtonDisabled?: boolean
}
const CmdbFormRelationView: React.FC<Props> = ({
  data,
  onSubmit,
  onCopy,
  saveButtonDisabled,
}) => {
  const formikProps = useFormikContext()
  return (
    <div style={{ marginLeft: 25, marginRight: 25 }}>
      <Typography variant="h1" align="center">
        <Translate
          entityName="cmdb"
          fieldName="heading"
          defaultMessage="cmdb"
        />
      </Typography>
      <Typography align="center">
        <Translate
          entityName="cmdb"
          fieldName="message"
          defaultMessage="Edit this text using the translate tool"
        />
      </Typography>
      <Box sx={{ marginY: 2 }}>
        <CardContent>
          <form onSubmit={formikProps.handleSubmit}>
            <Grid container spacing={3}>
              <FormCard title={'cmdb'}>
                <CmdbFormRelation rootName={'cmdb_by_pk' ?? 'ROOT_NAME'} />
                {undefined && formikProps?.setFieldValue && (
                  <CmdbLookupDialogWrapperForFormRelation
                    setFieldValue={formikProps?.setFieldValue}
                    replacedValue="ROOT_NAME.undefined"
                  />
                )}
              </FormCard>
            </Grid>
            <CardActions>
              <LoadingButton
                disabled={saveButtonDisabled}
                loading={formikProps.isSubmitting}
                loadingPosition="start"
                startIcon={<Save />}
                style={{
                  margin: '12px auto',
                }}
                variant="contained"
                type="submit"
                data-test-id="save-entity-button"
              >
                <Translate entityName="Save" />
              </LoadingButton>
              {onCopy !== undefined && (
                <LoadingButton
                  disabled={saveButtonDisabled}
                  color="secondary"
                  loading={formikProps.isSubmitting}
                  loadingPosition="start"
                  startIcon={<FileCopy />}
                  style={{
                    margin: '12px auto',
                  }}
                  variant="contained"
                  onClick={() => {
                    if (onCopy) {
                      onCopy(data as FormikValues, formikProps)
                    }
                  }}
                  data-test-id="copy-entity-button"
                >
                  <Translate entityName="Copy" />
                </LoadingButton>
              )}
            </CardActions>
          </form>
        </CardContent>
      </Box>
    </div>
  )
}
export default CmdbFormRelationView
