import React from 'react'
import { useParams, useNavigate, useSearchParams } from 'react-router-dom'
import {
  useCmdb_By_PkQuery,
  useInsert_CmdbMutation,
} from '../../../generated/graphql'
import {
  createEmptyObject,
  Error,
  ErrorBoundary,
  Fetching,
  parseRequestErrors,
  QueryBoundary,
  showErrorSnackbar,
  showLoadingSnackbar,
  showSuccessSnackbar,
  useFilter,
} from '@iteria-app/component-templates'
import { Formik, FormikHelpers, FormikValues } from 'formik'
import { getUpsertQuery } from '@iteria-app/graphql-lowcode'
import { useIntl } from 'react-intl'
import * as generatedGraphql from '../../../generated/graphql'
import introspection from '../../../generated/introspect.json'
interface IViewProps {
  data: generatedGraphql.CmdbQuery
  onSubmit: (
    values: FormikValues,
    formikHelpers: FormikHelpers<FormikValues>
  ) => void
}
interface CmdbFormContainerProps {
  View: React.FC<IViewProps>
}
const CmdbCreateContainer: React.FC<CmdbFormContainerProps> = ({ View }) => {
  const { id } = useParams()
  const navigate = useNavigate()
  const intl = useIntl()
  const [searchParams] = useSearchParams()
  const filterProps = useFilter(searchParams, 'cmdb')
  const [insertedData, insertMutation] = useInsert_CmdbMutation()
  let data
  if (filterProps?.id)
    [data] = useCmdb_By_PkQuery({
      variables: { CmdbId: filterProps?.id },
    })
  const handleSubmit = (
    values: FormikValues,
    formikHelpers: FormikHelpers<FormikValues>
  ) => {
    formikHelpers.setSubmitting(true)
    showLoadingSnackbar(
      intl.formatMessage({
        id: 'submit.inprogress',
        defaultMessage: 'Submitting...',
      })
    )
    insertMutation(getUpsertQuery(values, generatedGraphql)).then(
      (response) => {
        if (response.error) {
          showErrorSnackbar(
            intl.formatMessage({
              id: 'submit.failed',
              defaultMessage: 'Submit failed: ',
            }) + parseRequestErrors(response.error.message, intl)
          )
          console.error('Submit error:', response.error)
        } else {
          showSuccessSnackbar(
            intl.formatMessage({
              id: 'submit.successful',
              defaultMessage: 'Submit successful',
            })
          )
        }
        formikHelpers.setSubmitting(false)
        const newId =
          response.data?.[`${Object.keys(response.data)[0]}`]?.returning?.[0]
            ?.id
        if (newId) {
          navigate(-1)
        }
      }
    )
  }
  if (data?.fetching) return <Fetching />
  if (data?.error) return <Error error={data?.error} />
  return (
    <ErrorBoundary>
      <QueryBoundary queryResponse={data}>
        <Formik
          initialValues={
            data?.data ??
            createEmptyObject('customer', generatedGraphql, introspection)
          }
          onSubmit={handleSubmit}
          validateOnChange={false}
          validateOnBlur={false}
        >
          <View data={data?.data} onSubmit={handleSubmit} />
        </Formik>
      </QueryBoundary>
    </ErrorBoundary>
  )
}
export default CmdbCreateContainer
