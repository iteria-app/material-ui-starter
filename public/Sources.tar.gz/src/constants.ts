// Empty implementation for Rollup alias
export const createRequire = () => {}
