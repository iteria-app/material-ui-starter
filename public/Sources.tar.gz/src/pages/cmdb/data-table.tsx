import React from 'react'
import CmdbFilter from '../../components/entities/cmdb/CmdbFilter'
import CmdbDataTableContainerForForm from '../../components/entities/cmdb/CmdbDataTableContainerForForm'
import CmdbDataTableGridViewForForm from '../../components/entities/cmdb/CmdbDataTableGridViewForForm'
import {
  FilterDataStorage,
  FilterDrawer,
} from '@iteria-app/component-templates'
import { Box } from '@mui/material'
const CmdbManyPage: React.FC = () => {
  return (
    <CmdbDataTableContainerForForm
      View={({ data, error, loading, onClickRow, filterProps }) => (
        <>
          <Box>
            <FilterDrawer>
              <CmdbFilter
                filterCallbacks={filterProps}
                dataStorage={FilterDataStorage.QUERY_PARAMETERS}
              />
            </FilterDrawer>
            <CmdbDataTableGridViewForForm
              data={data?.cmdb}
              filterProps={filterProps}
              onClickRow={onClickRow}
              loading={loading}
              error={error}
            />
          </Box>
        </>
      )}
    />
  )
}
export default CmdbManyPage
export const INDEX_ROUTE = 'data-table'
