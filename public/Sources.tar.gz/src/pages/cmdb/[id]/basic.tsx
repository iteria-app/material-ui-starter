import React from 'react'
import CmdbFormBasicView from '../../../components/entities/cmdb/CmdbFormBasicView'
import CmdbFormBasicContainer from '../../../components/entities/cmdb/CmdbFormBasicContainer'
const CmdbFormBasicPage: React.FC = () => {
  return (
    <CmdbFormBasicContainer
      View={({ data, onSubmit, onCopy }) => (
        <CmdbFormBasicView data={data} onSubmit={onSubmit} onCopy={onCopy} />
      )}
    />
  )
}
export default CmdbFormBasicPage
// export const OUTLET_ROUTE = 'domysliet cestu k listu'
