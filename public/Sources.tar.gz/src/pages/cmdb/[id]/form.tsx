import React from 'react'
import CmdbFormView from '../../../components/entities/cmdb/CmdbFormView'
import CmdbFormContainer from '../../../components/entities/cmdb/CmdbFormContainer'
const CmdbFormPage: React.FC = () => {
  return (
    <CmdbFormContainer
      View={({ data, onSubmit, onCopy }) => (
        <CmdbFormView data={data} onSubmit={onSubmit} onCopy={onCopy} />
      )}
    />
  )
}
export default CmdbFormPage
// export const OUTLET_ROUTE = 'domysliet cestu k listu'
