import React from 'react'
import CmdbFormRelationView from '../../../components/entities/cmdb/CmdbFormRelationView'
import CmdbFormRelationContainer from '../../../components/entities/cmdb/CmdbFormRelationContainer'
const CmdbFormRelationPage: React.FC = () => {
  return (
    <CmdbFormRelationContainer
      View={({ data, onSubmit, onCopy }) => (
        <CmdbFormRelationView data={data} onSubmit={onSubmit} onCopy={onCopy} />
      )}
    />
  )
}
export default CmdbFormRelationPage
// export const OUTLET_ROUTE = 'domysliet cestu k listu'
