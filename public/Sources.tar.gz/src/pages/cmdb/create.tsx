import React from 'react'
import CmdbCreateFormView from '../../components/entities/cmdb/CmdbCreateFormView'
import CmdbCreateContainer from '../../components/entities/cmdb/CmdbCreateContainer'
const CmdbCreatePage: React.FC = () => {
  return (
    <CmdbCreateContainer
      View={({ data, onSubmit }) => (
        <>
          <CmdbCreateFormView data={data} onSubmit={onSubmit} />
        </>
      )}
    />
  )
}
export default CmdbCreatePage
