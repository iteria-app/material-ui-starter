Testovanie lowcode pred vypublikovanim (idealne pri preview pull requestov)
